package com.example.solattimefyp;

public class WaktuSolatDetail {
    public String title;
    public String description;

    public WaktuSolatDetail(){
        title = "";
        description = "";
    }
}
