package com.example.solattimefyp;

public interface WaktuSolatListCallback {
    public void onSuccess(WaktuSolatList waktuSolatList);
    public void onFailure(Message message);
}
