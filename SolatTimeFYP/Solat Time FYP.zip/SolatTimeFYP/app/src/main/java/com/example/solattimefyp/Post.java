package com.example.solattimefyp;

public class Post {
    public String getNegeri() {
        return negeri;
    }

    public String getKawasan() {
        return kawasan;
    }

    public String getSubuh() {
        return subuh;
    }

    public String getZohor() {
        return zohor;
    }

    public String getAsar() {
        return asar;
    }

    public String getMagrib() {
        return magrib;
    }

    public String getIsyak() {
        return isyak;
    }

    private String negeri, kawasan, subuh,zohor,asar,magrib,isyak;

}
